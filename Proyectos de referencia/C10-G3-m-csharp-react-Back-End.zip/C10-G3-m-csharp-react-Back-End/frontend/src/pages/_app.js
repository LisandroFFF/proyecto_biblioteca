import '@/styles/globals.css'
import '../scss/base/_generales.scss';

export default function App({ Component, pageProps }) {
  return <Component {...pageProps} />
}
