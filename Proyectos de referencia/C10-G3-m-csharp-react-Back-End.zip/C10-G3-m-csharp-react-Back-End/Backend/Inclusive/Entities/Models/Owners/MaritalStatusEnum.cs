﻿namespace Entities.Models.Owners;

public enum MaritalStatusEnum
{
    Married,
    Single,
    Divorced,
    Widowed,
    Separated,
    Other
}