﻿namespace Entities.Models.Owners;

public enum GenderEnum
{
    Male,
    Female,
    Other
}