﻿namespace Entities.Models.Owners;

public enum NationalityEnum
{
    Argentina,
    Bolivia,
    Brazil,
    Chile,
    Colombia,
    Ecuador,
    Paraguay,
    Peru,
    Uruguay,
    Venezuela,
    Other
}