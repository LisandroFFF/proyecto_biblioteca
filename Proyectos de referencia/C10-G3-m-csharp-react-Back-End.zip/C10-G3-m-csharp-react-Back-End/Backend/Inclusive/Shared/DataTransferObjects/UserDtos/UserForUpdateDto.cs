﻿namespace Shared.DataTransferObjects.UserDtos;

public record UserForUpdateDto : UserForManipulationDto
{
}