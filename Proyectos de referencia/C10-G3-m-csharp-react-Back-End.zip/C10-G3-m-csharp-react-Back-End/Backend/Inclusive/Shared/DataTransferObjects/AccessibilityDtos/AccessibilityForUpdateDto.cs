﻿
namespace Shared.DataTransferObjects.AccessibilityDtos;

public record AccessibilityForUpdateDto : AccessibilityForManipulationDto
{
}