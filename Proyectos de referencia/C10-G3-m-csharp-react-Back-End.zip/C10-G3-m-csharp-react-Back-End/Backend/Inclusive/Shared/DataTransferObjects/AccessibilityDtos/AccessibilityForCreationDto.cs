﻿using Microsoft.AspNetCore.Http;

namespace Shared.DataTransferObjects.AccessibilityDtos;

public record AccessibilityForCreationDto : AccessibilityForManipulationDto
{
}