﻿using Shared.DataTransferObjects.ReviewDtos;

namespace Shared.DataTransferObjects;

public record ReviewForUpdateDto : ReviewForManipulationDto
{
}