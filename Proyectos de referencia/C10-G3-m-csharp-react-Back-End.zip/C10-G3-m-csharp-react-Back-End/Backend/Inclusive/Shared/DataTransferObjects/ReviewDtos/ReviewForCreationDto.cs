﻿using Shared.DataTransferObjects.ReviewDtos;

namespace Shared.DataTransferObjects;

public record ReviewForCreationDto : ReviewForManipulationDto
{
}