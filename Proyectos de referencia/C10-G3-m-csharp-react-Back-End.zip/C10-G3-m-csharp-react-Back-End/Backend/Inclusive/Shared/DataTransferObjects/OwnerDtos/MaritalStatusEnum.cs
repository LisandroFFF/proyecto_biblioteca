﻿namespace Shared.DataTransferObjects.OwnerDtos;

public enum MaritalStatusEnum
{
    Married,
    Single,
    Divorced,
    Widowed,
    Separated,
    Other
}