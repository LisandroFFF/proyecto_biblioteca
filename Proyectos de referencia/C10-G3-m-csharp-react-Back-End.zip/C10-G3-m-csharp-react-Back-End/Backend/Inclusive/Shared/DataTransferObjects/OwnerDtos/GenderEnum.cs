﻿namespace Shared.DataTransferObjects.OwnerDtos;

public enum GenderEnum
{
    Male,
    Female,
    Other
}