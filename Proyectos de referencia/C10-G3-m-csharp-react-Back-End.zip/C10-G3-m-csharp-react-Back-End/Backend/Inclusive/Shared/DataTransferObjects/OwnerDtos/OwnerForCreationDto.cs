﻿
namespace Shared.DataTransferObjects.OwnerDtos;

public record OwnerForCreationDto : OwnerForManipulationDto
{
}