﻿namespace Inclusive.Presentation;

public static class AssemblyReference
{
    
}