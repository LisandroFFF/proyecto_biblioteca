﻿using System.Linq.Dynamic.Core;
using System.Reflection;
using Entities.Models;

namespace Repository.Extensions;

public static class RepositoryCategoryExtensions
{
}