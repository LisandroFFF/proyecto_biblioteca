## Equipo
### Front-End

* Luis Simosa

* Exequiel Portero

* Ezequiel Sanchez

* Gerson Flores 

### Back-End

* Alejandro Toso

* Juan Pablo Rodriguez

* Santiago D'Addona


### UX/UI

* Alejandro Dieguez

* Fabián Cárdenas  

* Natalia Gabriela Chehda
