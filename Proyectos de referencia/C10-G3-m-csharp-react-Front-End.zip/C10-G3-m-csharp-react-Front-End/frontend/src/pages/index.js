import HomeView from "@/components/homeView/homeView"

export default function Home() {
  return (
    <>
      <HomeView/>
    </>
  )
}
